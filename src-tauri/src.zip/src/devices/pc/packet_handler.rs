use crate::net::ipv4::{IpNextHeaderProtocol, Ipv4};
use crate::net::arp::{Arp, ArpOperation};
use crate::net::icmp::Icmp;

impl PC {
    pub async fn handle_packet(&mut self, in_idx: usize, packet: Vec<u8>) {
        let frame = match Ethernet::from_bytes(&packet) {
            Ok(frame) => frame,
            Err(_) => return,
        };

        match frame.ethertype {
            EtherType::Arp => { self.handle_arp(in_idx, frame).await; }
            EtherType::Ipv4 => { self.handle_ipv4(in_idx, frame).await; }
            _ => { /* DROP  */ }
        }
    }

    async fn handle_arp(
        &mut self,
        in_idx: usize,
        frame: Ethernet,
    ) {
        let arp = match Arp::from_bytes(&frame.payload) {
            Ok(arp) => arp,
            Err(_) => return,
        };

        match arp.operation {
            ArpOperation::Request => {
                self.handle_arp_request(in_idx, arp).await;
            }

            ArpOperation::Reply => {
                self.handle_arp_reply(arp).await;
            }

            _ => {}
        }

    }

    async fn handle_ipv4(
        &mut self,
        in_idx: usize,
        frame: Ethernet,
    ) {
        let packet = match Ipv4::from_bytes(&frame.payload) {
            Ok(packet) => packet,
            Err(_) => return,
        };

        if !packet.verify_checksum() {
            return;
        }

        match packet.next_level_protocol {
            IpNextHeaderProtocol::Icmp => {
                self.handle_icmp(in_idx, frame, packet).await;
            }

            _ => {}
        }
    }

    async fn handle_icmp(
        &mut self,
        in_idx: usize,
        frame: Ethernet,
    ) {
        let icmp = match Icmp::from_bytes(&packet.payload) {
            Ok(icmp) => icmp,
            Err(_) => return,
        };

        if !icmp.verify_checksum() {
            return;
        }

        if icmp.is_echo_request() {
            self.handle_icmp_echo_request(
                in_idx,
                frame,
                packet,
                icmp,
            ).await;
        }
    }
}